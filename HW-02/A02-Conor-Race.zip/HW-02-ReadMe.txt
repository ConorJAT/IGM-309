Course: IGME 309
Student: Conor Race
Assignment: #02

Polygon Drawer - How To Use
  - Left Click: Add a vertex.
  - 'Enter' Key: Finish current shape (and start new shape).
  - Right Click: Open setting menu (Clear, Change Color, Exit).